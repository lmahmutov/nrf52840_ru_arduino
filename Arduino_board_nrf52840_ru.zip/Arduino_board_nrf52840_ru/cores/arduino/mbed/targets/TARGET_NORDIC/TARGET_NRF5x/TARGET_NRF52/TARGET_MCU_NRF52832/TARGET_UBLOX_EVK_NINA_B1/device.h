#ifndef MBED_DEVICE_H
#define MBED_DEVICE_H

#include "objects.h"

#endif
