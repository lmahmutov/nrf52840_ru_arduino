/********************************************************************************
 * \copyright
 * \copyright
 * Copyright 2018-2018, ARM Limited. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/

#ifndef MBED_DEVICE_H
#define MBED_DEVICE_H

#include "objects.h"

#endif
